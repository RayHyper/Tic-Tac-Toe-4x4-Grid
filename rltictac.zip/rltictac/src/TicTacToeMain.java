/**Programmer: Raymond Lam
 * Date: May 28, 2022
 * ICS4U1-02
 * Tic Tac Toe Game
 * This program uses arrays to simulate a tic tac toe game. 
 * There will be a grid and the users will take turns clicking 
 * the tiles until a match is found
 * 
 * I made this game completely from scratch. The logic is the same from the tic tac toe program from brightspace. 
*  First make an array with 4 rows and 4 columns. Since 0 is placed automatically in each index,
*  I put -999 numbers in each index so it would have values that was not matching. 
*  Every time a user clicks a button a 1 or 0 is placed in the specific index. 1 to represent X and 0 to represent O. 
*  Then it will see if the a row, column or diagonal numbers are the same and will output the winner. For example all 1s will indicate x’s are matching. 
*  Or all 0s will indicate O’s are matching. This game also show the state of the game in the console window. 
*  You can see each index in the array and the value stored in it.
* 
 * Extra Features
 * 
 * -Added menu screen
 * -Changed font and look of the game
 * -When start button is pressed it turns red
 * -You can not click a tile twice, this prevents users from breaking the program
 * -When a match is found it will light up in cyan
 * -It shows who's turn it is X or O
 * -Dialog box appears saying who won
 * -When game is finished you cant click any other buttons except for the restart button
 * -Shows number of times X and O wins
 * -Can go back to starting menu
 * -If you look at the TicTacToeMain.java console and run the game at the same time
 * you can see each array index and what is happening in the array
 */


//import java libraries
import java.awt.Color;
import java.util.Arrays;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class TicTacToeMain extends javax.swing.JFrame {
    
    //get images from resource folder
    ImageIcon a = new ImageIcon(getClass().getResource("/Resource/mark-x.png"));
    ImageIcon b = new ImageIcon(getClass().getResource("/Resource/circle.png"));
    ImageIcon cardBack = new ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"));

    //game is not started yet
    boolean gameStarted = false;

    //declare variables
    int number = 0;
    int winner;
    int gameDone = 0;
    int oWins = 0, xWins = 0, ties = 0;
    
    boolean alreadyPressed, alreadyPressed2, alreadyPressed3, alreadyPressed4,
            alreadyPressed5, alreadyPressed6, alreadyPressed7, alreadyPressed8, 
            alreadyPressed9,alreadyPressed10, alreadyPressed11, alreadyPressed12, 
            alreadyPressed13, alreadyPressed14, alreadyPressed15, alreadyPressed16 = false;

    //array with three rows and three columns
    int[][] check = new int[4][4];
    

    /**
     * Creates new form TicTacToeMain
     */
    public TicTacToeMain() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tile3 = new javax.swing.JButton();
        tile4 = new javax.swing.JButton();
        tile2 = new javax.swing.JButton();
        tile1 = new javax.swing.JButton();
        tile5 = new javax.swing.JButton();
        tile6 = new javax.swing.JButton();
        tile7 = new javax.swing.JButton();
        tile8 = new javax.swing.JButton();
        tile9 = new javax.swing.JButton();
        tile10 = new javax.swing.JButton();
        tile11 = new javax.swing.JButton();
        tile12 = new javax.swing.JButton();
        tile13 = new javax.swing.JButton();
        tile14 = new javax.swing.JButton();
        tile15 = new javax.swing.JButton();
        tile16 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        startButton = new javax.swing.JToggleButton();
        backButton = new javax.swing.JButton();
        restartButton = new javax.swing.JToggleButton();
        oWinOutput = new javax.swing.JLabel();
        xWinOutput1 = new javax.swing.JLabel();
        playerOutput = new javax.swing.JLabel();
        tieOutput = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Tic Tac Toe");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tile3.setBackground(new java.awt.Color(255, 255, 255));
        tile3.setForeground(new java.awt.Color(255, 255, 255));
        tile3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile3MouseClicked(evt);
            }
        });
        getContentPane().add(tile3, new org.netbeans.lib.awtextra.AbsoluteConstraints(213, 0, 99, 94));

        tile4.setBackground(new java.awt.Color(255, 255, 255));
        tile4.setForeground(new java.awt.Color(255, 255, 255));
        tile4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile4MouseClicked(evt);
            }
        });
        getContentPane().add(tile4, new org.netbeans.lib.awtextra.AbsoluteConstraints(319, 0, 99, 94));

        tile2.setBackground(new java.awt.Color(255, 255, 255));
        tile2.setForeground(new java.awt.Color(255, 255, 255));
        tile2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile2MouseClicked(evt);
            }
        });
        getContentPane().add(tile2, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 0, 99, 94));

        tile1.setBackground(new java.awt.Color(255, 255, 255));
        tile1.setForeground(new java.awt.Color(255, 255, 255));
        tile1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile1MouseClicked(evt);
            }
        });
        getContentPane().add(tile1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 0, 99, 94));

        tile5.setBackground(new java.awt.Color(255, 255, 255));
        tile5.setForeground(new java.awt.Color(255, 255, 255));
        tile5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile5MouseClicked(evt);
            }
        });
        getContentPane().add(tile5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 101, 99, 94));

        tile6.setBackground(new java.awt.Color(255, 255, 255));
        tile6.setForeground(new java.awt.Color(255, 255, 255));
        tile6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile6MouseClicked(evt);
            }
        });
        getContentPane().add(tile6, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 101, 99, 94));

        tile7.setBackground(new java.awt.Color(255, 255, 255));
        tile7.setForeground(new java.awt.Color(255, 255, 255));
        tile7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile7MouseClicked(evt);
            }
        });
        getContentPane().add(tile7, new org.netbeans.lib.awtextra.AbsoluteConstraints(213, 101, 99, 94));

        tile8.setBackground(new java.awt.Color(255, 255, 255));
        tile8.setForeground(new java.awt.Color(255, 255, 255));
        tile8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile8MouseClicked(evt);
            }
        });
        getContentPane().add(tile8, new org.netbeans.lib.awtextra.AbsoluteConstraints(319, 101, 99, 94));

        tile9.setBackground(new java.awt.Color(255, 255, 255));
        tile9.setForeground(new java.awt.Color(255, 255, 255));
        tile9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile9MouseClicked(evt);
            }
        });
        getContentPane().add(tile9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 202, 99, 94));

        tile10.setBackground(new java.awt.Color(255, 255, 255));
        tile10.setForeground(new java.awt.Color(255, 255, 255));
        tile10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile10MouseClicked(evt);
            }
        });
        getContentPane().add(tile10, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 202, 99, 94));

        tile11.setBackground(new java.awt.Color(255, 255, 255));
        tile11.setForeground(new java.awt.Color(255, 255, 255));
        tile11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile11MouseClicked(evt);
            }
        });
        getContentPane().add(tile11, new org.netbeans.lib.awtextra.AbsoluteConstraints(213, 202, 99, 94));

        tile12.setBackground(new java.awt.Color(255, 255, 255));
        tile12.setForeground(new java.awt.Color(255, 255, 255));
        tile12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile12MouseClicked(evt);
            }
        });
        getContentPane().add(tile12, new org.netbeans.lib.awtextra.AbsoluteConstraints(319, 202, 99, 94));

        tile13.setBackground(new java.awt.Color(255, 255, 255));
        tile13.setForeground(new java.awt.Color(255, 255, 255));
        tile13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile13MouseClicked(evt);
            }
        });
        getContentPane().add(tile13, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 303, 99, 94));

        tile14.setBackground(new java.awt.Color(255, 255, 255));
        tile14.setForeground(new java.awt.Color(255, 255, 255));
        tile14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile14MouseClicked(evt);
            }
        });
        getContentPane().add(tile14, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 303, 99, 94));

        tile15.setBackground(new java.awt.Color(255, 255, 255));
        tile15.setForeground(new java.awt.Color(255, 255, 255));
        tile15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile15MouseClicked(evt);
            }
        });
        getContentPane().add(tile15, new org.netbeans.lib.awtextra.AbsoluteConstraints(213, 303, 99, 94));

        tile16.setBackground(new java.awt.Color(255, 255, 255));
        tile16.setForeground(new java.awt.Color(255, 255, 255));
        tile16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pure-white-background-85a2a7fd.jpg"))); // NOI18N
        tile16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tile16MouseClicked(evt);
            }
        });
        getContentPane().add(tile16, new org.netbeans.lib.awtextra.AbsoluteConstraints(319, 303, 99, 94));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setForeground(new java.awt.Color(204, 204, 204));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 400));

        jPanel2.setBackground(new java.awt.Color(26, 25, 120));
        jPanel2.setForeground(new java.awt.Color(26, 25, 120));

        startButton.setBackground(new java.awt.Color(51, 255, 0));
        startButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        startButton.setText("Start");
        startButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });

        backButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/back.PNG"))); // NOI18N
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        restartButton.setBackground(new java.awt.Color(0, 153, 255));
        restartButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        restartButton.setText("Restart");
        restartButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        restartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restartButtonActionPerformed(evt);
            }
        });

        oWinOutput.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        oWinOutput.setForeground(new java.awt.Color(255, 255, 255));
        oWinOutput.setText("O wins = 0");

        xWinOutput1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        xWinOutput1.setForeground(new java.awt.Color(255, 255, 255));
        xWinOutput1.setText("X wins = 0");

        playerOutput.setForeground(new java.awt.Color(255, 255, 255));

        tieOutput.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        tieOutput.setForeground(new java.awt.Color(255, 255, 255));
        tieOutput.setText("Ties = 0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(oWinOutput)
                    .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(playerOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tieOutput)
                        .addGap(28, 28, 28)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(xWinOutput1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(restartButton, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(34, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(xWinOutput1)
                    .addComponent(oWinOutput)
                    .addComponent(tieOutput))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(playerOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                        .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(restartButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 420, 120));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tile1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile1MouseClicked
        //when tile1 is clicked and game has started
        if (alreadyPressed == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;

            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile1.setIcon(a);
                //put 1 to represent x into the array
                check[0][0] = 1;

            } else {
                
                //output o icon to button
                tile1.setIcon(b);
                //put 0 icon to represent o into the array
                check[0][0] = 0;
            }
            //calls the check method to see if there are any matches
            checking();

            //increases so next turn is the other player
            number++;

            //makes it so you can not click the button twice
            alreadyPressed = true;
        }
    }//GEN-LAST:event_tile1MouseClicked

    private void tile2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile2MouseClicked
        //when tile2 is clicked and game has started
        if (alreadyPressed2 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {     
                
                //output x icon to button
                tile2.setIcon(a);   
                //put 1 to represent x into the array
                check[0][1] = 1;
            } else {   
                
                //output o icon to button
                tile2.setIcon(b);
                //put 0 icon to represent o into the array
                check[0][1] = 0;
            }
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed2 = true;
        }
    }//GEN-LAST:event_tile2MouseClicked

    private void tile3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile3MouseClicked
       //when tile3 is clicked and game has started
        if (alreadyPressed3 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile3.setIcon(a);
                //put 1 to represent x into the array
                check[0][2] = 1;
            } else {
                
                //output o icon to button
                tile3.setIcon(b);
                //put 0 icon to represent o into the array
                check[0][2] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed3 = true;
        }
    }//GEN-LAST:event_tile3MouseClicked

    private void tile4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile4MouseClicked
        //when tile4 is clicked and game has started
        if (alreadyPressed4 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile4.setIcon(a);
                //put 1 to represent x into the array
                check[0][3] = 1;
            } else {
                
                //output o icon to button
                tile4.setIcon(b);
                //put 0 icon to represent o into the array
                check[0][3] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed4 = true;
        }
    }//GEN-LAST:event_tile4MouseClicked

    private void tile5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile5MouseClicked
        //when tile5 is clicked and game has started
        if (alreadyPressed5 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile5.setIcon(a);
                //put 1 to represent x into the array
                check[1][0] = 1;
            } else {
                
                //output o icon to button
                tile5.setIcon(b);
                //put 0 icon to represent o into the array
                check[1][0] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed5 = true;
        }
    }//GEN-LAST:event_tile5MouseClicked

    private void tile6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile6MouseClicked
        //when tile6 is clicked and game has started
        if (alreadyPressed6 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile6.setIcon(a);
                //put 1 to represent x into the array
                check[1][1] = 1;
            } else {
                
                //output o icon to button
                tile6.setIcon(b);
                //put 0 icon to represent o into the array
                check[1][1] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed6 = true;
        }
    }//GEN-LAST:event_tile6MouseClicked

    private void tile7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile7MouseClicked
        //when tile7 is clicked and game has started
        if (alreadyPressed7 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile7.setIcon(a);
                //put 1 to represent x into the array
                check[1][2] = 1;
            } else {
                
                //output o icon to button
                tile7.setIcon(b);
                //put 0 icon to represent o into the array
                check[1][2] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed7 = true;
        }
    }//GEN-LAST:event_tile7MouseClicked

    private void tile8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile8MouseClicked
        //when tile8 is clicked and game has started
        if (alreadyPressed8 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile8.setIcon(a);
                //put 1 to represent x into the array
                check[1][3] = 1;
            } else {
                
                //output o icon to button
                tile8.setIcon(b);
                //put 0 icon to represent o into the array
                check[1][3] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed8 = true;
        }
    }//GEN-LAST:event_tile8MouseClicked

    private void tile9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile9MouseClicked
        //when tile9 is clicked and game has started
        if (alreadyPressed9 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile9.setIcon(a);
                //put 1 to represent x into the array
                check[2][0] = 1;
            } else {
                
                //output o icon to button
                tile9.setIcon(b);
                //put 0 icon to represent o into the array
                check[2][0] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed9 = true;
        }
    }//GEN-LAST:event_tile9MouseClicked

    private void tile10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile10MouseClicked
        //when tile10 is clicked and game has started
        if (alreadyPressed10 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile10.setIcon(a);
                //put 1 to represent x into the array
                check[2][1] = 1;
            } else {
                
                //output o icon to button
                tile10.setIcon(b);
                //put 0 icon to represent o into the array
                check[2][1] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed10 = true;
        }
    }//GEN-LAST:event_tile10MouseClicked

    private void tile11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile11MouseClicked
        //when tile11 is clicked and game has started
        if (alreadyPressed11 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile11.setIcon(a);
                //put 1 to represent x into the array
                check[2][2] = 1;
            } else {
                
                //output o icon to button
                tile11.setIcon(b);
                //put 0 icon to represent o into the array
                check[2][2] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed11 = true;
        }
    }//GEN-LAST:event_tile11MouseClicked

    private void tile12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile12MouseClicked
        //when tile12 is clicked and game has started
        if (alreadyPressed12 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile12.setIcon(a);
                //put 1 to represent x into the array
                check[2][3] = 1;
            } else {
                
                //output o icon to button
                tile12.setIcon(b);
                //put 0 icon to represent o into the array
                check[2][3] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed12 = true;
        }
    }//GEN-LAST:event_tile12MouseClicked

    private void tile13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile13MouseClicked
        //when tile13 is clicked and game has started
        if (alreadyPressed13 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile13.setIcon(a);
                //put 1 to represent x into the array
                check[3][0] = 1;
            } else {
                
                //output o icon to button
                tile13.setIcon(b);
                //put 0 icon to represent o into the array
                check[3][0] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed13 = true;
        }
    }//GEN-LAST:event_tile13MouseClicked

    private void tile14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile14MouseClicked
        //when tile14 is clicked and game has started
        if (alreadyPressed14 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile14.setIcon(a);
                //put 1 to represent x into the array
                check[3][1] = 1;
            } else {
                
                //output o icon to button
                tile14.setIcon(b);
                //put 0 icon to represent o into the array
                check[3][1] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed14 = true;
        }
    }//GEN-LAST:event_tile14MouseClicked

    private void tile15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile15MouseClicked
        //when tile15 is clicked and game has started
        if (alreadyPressed15 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile15.setIcon(a);
                //put 1 to represent x into the array
                check[3][2] = 1;
            } else {
                
                //output o icon to button
                tile15.setIcon(b);
                //put 0 icon to represent o into the array
                check[3][2] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed15 = true;
        }
    }//GEN-LAST:event_tile15MouseClicked

    private void tile16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tile16MouseClicked
        //when tile16 is clicked and game has started
        if (alreadyPressed16 == false && gameStarted == true) {
            
            //increases variable by 1
            gameDone++;
            
            //checks if number is even
            if (number % 2 == 0) {
                
                //output x icon to button
                tile16.setIcon(a);
                //put 1 to represent x into the array
                check[3][3] = 1;
            } else {
                
                //output o icon to button
                tile16.setIcon(b);
                //put 0 icon to represent o into the array
                check[3][3] = 0;
            }
            
            //calls the check method to see if there are any matches
            checking();
            
            //increases so next turn is the other player
            number++;
            
            //makes it so you can not click the button twice
            alreadyPressed16 = true;
        }
    }//GEN-LAST:event_tile16MouseClicked
    
    //start button is not pressed yet
    boolean startButtonPressed = false;
    
    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
        //prevents the user from clicking start twice
        if (startButtonPressed == false) {
            startButtonPressed = true;
           
            //set button red to show game is running
            startButton.setBackground(Color.RED);
            
            //set game to running
            gameStarted = true;

            //declare variable
            int counter = 1;

            //sets each element in the array to -999 numbers for place holders
            for (int i = 0; i < check[0].length; i++) {
                for (int j = 0; j < check.length; j++) {
                    //when creating an array it auto sets each element to 0
                    //this overrides that and set different numbers
                    check[i][j] = -999 + counter;
                    //increase counter by 1
                    counter++;
                }
            }
        }
    }//GEN-LAST:event_startButtonActionPerformed

    //declare status variable
    int statusNum = 0;
    
    //check match method
    public void checking() {
        
        //if number is even output player o turn
        if (number % 2 == 0) {
            playerOutput.setText("Player O Turn");
        }
        //else output player x turn
        else {

            playerOutput.setText("Player X Turn");
        }
        
        //increase status variable by 1
        statusNum++;
        
        //status of game output
        System.out.println("Status " + statusNum + " turn");
        System.out.println("------------------------");
        
        //goes through each element in the array
        //this shows the status of the game in the console
        //this helps when you are trying to trouble shoot the code or find bugs
        for (int i = 0; i < check[0].length; i++) {
            for (int j = 0; j < check.length; j++) {
                
                //output the element currently in the array to the console
                System.out.println("At [" + i + "]" + " " + "[" + j + "]" + "=" + check[i][j]);

            }
        }

//check horizontal rows to see any matches
        //check row 0 if matches
        if (check[0][0] == check[0][1] && check[0][2] == check[0][3] && check[0][2] == check[0][0]) {
            //checks the icon that matches
            winner = check[0][0];
            
            //if the icon is a o
            if (winner == 0) {
                
                //set the tiles to turn cyan
                tile1.setBackground(Color.CYAN);
                tile2.setBackground(Color.CYAN);
                tile3.setBackground(Color.CYAN);
                tile4.setBackground(Color.CYAN);
                //have dialog box that says o is winner
                JOptionPane.showMessageDialog(this, " O Winner!");
                 playerOutput.setText("O wins");
                 //increases the number of wins o has by 1
                oWins++;
                //ends game so you can't click tiles
                gameStarted = false;

            } 
            
            //if the icon is a X
            else if (winner == 1) {
                
                //set the tiles to turn cyan
                tile1.setBackground(Color.CYAN);
                tile2.setBackground(Color.CYAN);
                tile3.setBackground(Color.CYAN);
                tile4.setBackground(Color.CYAN);
                //have dialog box that says X is winner
                JOptionPane.showMessageDialog(this, " X Winner!");            
                //increases the number of wins X has by 1
                playerOutput.setText("X wins");
                xWins++;
                //ends game so you can't click tiles
                gameStarted = false;
            }

        } 

        //check row 1 if matches
        else if (check[1][0] == check[1][1] && check[1][2] == check[1][3] && check[1][2] == check[1][0]) {
            //if the icon is a o
            winner = check[1][0];
            if (winner == 0) {
                
                //set the tiles to turn cyan
                tile5.setBackground(Color.CYAN);
                tile6.setBackground(Color.CYAN);
                tile7.setBackground(Color.CYAN);
                tile8.setBackground(Color.CYAN);
                //have dialog box that says o is winner
                JOptionPane.showMessageDialog(this, " O Winner!");
                playerOutput.setText("O wins");
                //increases the number of wins o has by 1
                oWins++;
                //ends game so you can't click tiles
                gameStarted = false;
            }          
            else if (winner == 1) {
                
                //set the tiles to turn cyan
                tile5.setBackground(Color.CYAN);
                tile6.setBackground(Color.CYAN);
                tile7.setBackground(Color.CYAN);
                tile8.setBackground(Color.CYAN);
                //have dialog box that says X is winner
                JOptionPane.showMessageDialog(this, " X Winner!");
                playerOutput.setText("X wins");
                //increases the number of wins X has by 1
                xWins++;
                //ends game so you can't click tiles
                gameStarted = false;
            }
          
        } 
          
        //check row 2 if matches
        else if (check[2][0] == check[2][1] && check[2][2] == check[2][3] && check[2][2] == check[2][0]) {
            //checks the icon that matches
            winner = check[2][0];
            
            //if the icon is a o
            if (winner == 0) {
                
                //set the tiles to turn cyan
                tile9.setBackground(Color.CYAN);
                tile10.setBackground(Color.CYAN);
                tile11.setBackground(Color.CYAN);
                tile12.setBackground(Color.CYAN);
                //have dialog box that says o is winner
                JOptionPane.showMessageDialog(this, " O Winner!");
                playerOutput.setText("O wins");
                //increases the number of wins o has by 1
                oWins++;
                //ends game so you can't click tiles
                gameStarted = false;
            }
            //if the icon is a X
            else if (winner == 1) {
                
                 //set the tiles to turn cyan
                tile9.setBackground(Color.CYAN);
                tile10.setBackground(Color.CYAN);
                tile11.setBackground(Color.CYAN);
                tile12.setBackground(Color.CYAN);
                //have dialog box that says X is winner
                JOptionPane.showMessageDialog(this, " X Winner!");
                playerOutput.setText("X wins");
                //increases the number of wins X has by 1
                xWins++;
                //ends game so you can't click tiles
                gameStarted = false;
            }

        }
         //check row 3 if matches
        
            else if (check[3][0] == check[3][1] && check[3][2] == check[3][3] && check[3][2] == check[3][0]) {
                 //checks the icon that matches
                winner = check[3][0];
                //if the icon is a o
                if (winner == 0) {
                    //set the tiles to turn cyan
                    tile13.setBackground(Color.CYAN);
                    tile14.setBackground(Color.CYAN);
                    tile15.setBackground(Color.CYAN);
                    tile16.setBackground(Color.CYAN);
                    //have dialog box that says o is winner
                    JOptionPane.showMessageDialog(this, " O Winner!");
                    playerOutput.setText("O wins");
                    //increases the number of wins o has by 1
                    oWins++;
                    //ends game so you can't click tiles
                    gameStarted = false;
                } 
                //if the icon is a X
                else if (winner == 1) {
                    
                     //set the tiles to turn cyan
                    tile13.setBackground(Color.CYAN);
                    tile14.setBackground(Color.CYAN);
                    tile15.setBackground(Color.CYAN);
                    tile16.setBackground(Color.CYAN);
                    //have dialog box that says X is winner
                    JOptionPane.showMessageDialog(this, " X Winner!");
                    playerOutput.setText("X wins");
                    //increases the number of wins X has by 1
                    xWins++;
                    //ends game so you can't click tiles
                    gameStarted = false;
                }
                    
            }
                
            //check vertical columns
            //if column 0 matches
            else if (check[0][0] == check[1][0] && check[2][0] == check[3][0] && check[2][0] == check[0][0]) {
                //checks the icon that matches
                winner = check[0][0];
                
                 //if the icon is a o
                if (winner == 0) {
                    
                    //set the tiles to turn cyan
                    tile1.setBackground(Color.CYAN);
                    tile5.setBackground(Color.CYAN);
                    tile9.setBackground(Color.CYAN);
                    tile13.setBackground(Color.CYAN);
                    //have dialog box that says o is winner
                    JOptionPane.showMessageDialog(this, " O Winner!");
                    playerOutput.setText("O wins");
                    //increases the number of wins o has by 1
                    oWins++;
                    //ends game so you can't click tiles
                    gameStarted = false;
                } 
                //if the icon is a X              
                else if (winner == 1) {
                    
                    //set the tiles to turn cyan
                    tile1.setBackground(Color.CYAN);
                    tile5.setBackground(Color.CYAN);
                    tile9.setBackground(Color.CYAN);
                    tile13.setBackground(Color.CYAN);
                    //have dialog box that says X is winner
                    JOptionPane.showMessageDialog(this, " X Winner!");
                    playerOutput.setText("X wins");
                    //increases the number of wins X has by 1
                    xWins++;
                    //ends game so you can't click tiles
                    gameStarted = false;
                }
            } 
            //if column 1 matches
            else if (check[0][1] == check[1][1] && check[2][1] == check[3][1] && check[2][1] == check[0][1]) {
                 //checks the icon that matches
                winner = check[0][1];
                //if the icon is a o
                if (winner == 0) {
                    
                     //set the tiles to turn cyan
                    tile2.setBackground(Color.CYAN);
                    tile6.setBackground(Color.CYAN);
                    tile10.setBackground(Color.CYAN);
                    tile14.setBackground(Color.CYAN);
                    //have dialog box that says o is winner
                    JOptionPane.showMessageDialog(this, " O Winner!");
                    playerOutput.setText("O wins");
                    //increases the number of wins o has by 1
                    oWins++;
                    //ends game so you can't click tiles
                    gameStarted = false;
                } 
                 //if the icon is a X
                else if (winner == 1) {
                    
                    //set the tiles to turn cyan
                    tile2.setBackground(Color.CYAN);
                    tile6.setBackground(Color.CYAN);
                    tile10.setBackground(Color.CYAN);
                    tile14.setBackground(Color.CYAN);
                    //have dialog box that says X is winner
                    JOptionPane.showMessageDialog(this, " X Winner!");
                    playerOutput.setText("X wins");
                    //increases the number of wins X has by 1
                    xWins++;
                    //ends game so you can't click tiles
                    gameStarted = false;
                }               
            } 
            
            //if column 2 matches
            else if (check[0][2] == check[1][2] && check[2][2] == check[3][2] && check[2][2] == check[0][2]) {
                //checks the icon that matches
                winner = check[0][2];
                //if the icon is a o
                if (winner == 0) {
                    
                    //set the tiles to turn cyan
                    tile3.setBackground(Color.CYAN);
                    tile7.setBackground(Color.CYAN);
                    tile11.setBackground(Color.CYAN);
                    tile15.setBackground(Color.CYAN);
                    //have dialog box that says o is winner
                    JOptionPane.showMessageDialog(this, " O Winner!");
                    playerOutput.setText("O wins");
                    //increases the number of wins o has by 1
                    oWins++;
                    //ends game so you can't click tiles
                    gameStarted = false;
                } 
                //if the icon is a X
                else if (winner == 1) {
                    
                     //set the tiles to turn cyan
                    tile3.setBackground(Color.CYAN);
                    tile7.setBackground(Color.CYAN);
                    tile11.setBackground(Color.CYAN);
                    tile15.setBackground(Color.CYAN);
                    
                    //have dialog box that says X is winner
                    JOptionPane.showMessageDialog(this, " X Winner!");
                    playerOutput.setText("X wins");
                    
                    //increases the number of wins X has by 1
                    xWins++;
                    
                    //ends game so you can't click tiles
                    gameStarted = false;
                }

            } 
            
            //if column3 matches
            else if (check[0][3] == check[1][3] && check[2][3] == check[3][3] && check[2][3] == check[0][3]) {
                 //checks the icon that matches
                winner = check[0][3];
                //if the icon is a o
                if (winner == 0) {
                    
                     //set the tiles to turn cyan
                    tile4.setBackground(Color.CYAN);
                    tile8.setBackground(Color.CYAN);
                    tile12.setBackground(Color.CYAN);
                    tile16.setBackground(Color.CYAN);
                    
                    //have dialog box that says o is winner
                    JOptionPane.showMessageDialog(this, " O Winner!");
                    playerOutput.setText("O wins");
                    
                    //increases the number of wins o has by 1
                    oWins++;
                    
                    //ends game so you can't click tiles
                    gameStarted = false;
                } 
                //if the icon is a X
                else if (winner == 1) {
                    
                    //set the tiles to turn cyan
                    tile4.setBackground(Color.CYAN);
                    tile8.setBackground(Color.CYAN);
                    tile12.setBackground(Color.CYAN);
                    tile16.setBackground(Color.CYAN);
                    
                    //have dialog box that says X is winner
                    JOptionPane.showMessageDialog(this, " X Winner!");
                    playerOutput.setText("X wins");
                    
                    //increases the number of wins X has by 1
                    xWins++;
                    
                    //ends game so you can't click tiles
                    gameStarted = false;
                } 
              
            }
                //check the diagonals
                //if right diagonal going down matches
                else if (check[0][0] == check[1][1] && check[2][2] == check[3][3] && check[2][2] == check[0][0]) {
                    //checks the icon that matches
                    winner = check[0][0];
                    if (winner == 0) {
                        
                        //set the tiles to turn cyan
                        tile1.setBackground(Color.CYAN);
                        tile6.setBackground(Color.CYAN);
                        tile11.setBackground(Color.CYAN);
                        tile16.setBackground(Color.CYAN);
                        //have dialog box that says o is winner
                        
                        JOptionPane.showMessageDialog(this, " O Winner!");
                        playerOutput.setText("O wins");
                        
                        //increases the number of wins o has by 1
                        oWins++;
                        
                        //ends game so you can't click tiles
                        gameStarted = false;
                    } 
                    //if the icon is a X
                    else if (winner == 1) {
                        
                        //set the tiles to turn cyan
                        tile1.setBackground(Color.CYAN);
                        tile6.setBackground(Color.CYAN);
                        tile11.setBackground(Color.CYAN);
                        tile16.setBackground(Color.CYAN);
                        
                        //have dialog box that says X is winner
                        JOptionPane.showMessageDialog(this, " X Winner!");
                        playerOutput.setText("X wins");
                        
                        //increases the number of wins X has by 1
                        xWins++;
                        
                        //ends game so you can't click tiles
                        gameStarted = false;
                    }

                } 
                              
                //if left diagonal going down matches
                else if (check[0][3] == check[1][2] && check[2][1] == check[3][0] && check[2][1] == check[0][3]) {
                    //checks the icon that matches
                    winner = check[0][3];
                    //if the icon is a o
                    if (winner == 0) {
                        
                        //set the tiles to turn cyan
                        tile4.setBackground(Color.CYAN);
                        tile7.setBackground(Color.CYAN);
                        tile10.setBackground(Color.CYAN);
                        tile13.setBackground(Color.CYAN);
                        
                        //have dialog box that says o is winner
                        JOptionPane.showMessageDialog(this, " O Winner!");
                        playerOutput.setText("O wins");
                        
                        //increases the number of wins o has by 1
                        oWins++;
                        
                        //ends game so you can't click tiles
                        gameStarted = false;
                    } 
                    //if the icon is a X
                    else if (winner == 1) {
                        
                         //set the tiles to turn cyan
                        tile4.setBackground(Color.CYAN);
                        tile7.setBackground(Color.CYAN);
                        tile10.setBackground(Color.CYAN);
                        tile13.setBackground(Color.CYAN);
                        
                        //have dialog box that says X is winner
                        JOptionPane.showMessageDialog(this, " X Winner!");
                        playerOutput.setText("X wins");
                        
                        //increases the number of wins X has by 1
                        xWins++;
                        
                        //ends game so you can't click tiles
                        gameStarted = false;
                    }

                }
                //check tie
                else {
                    //when all tiles are pressed
                    if (gameDone == 16) {

                        //output dialog box to show tie
                        JOptionPane.showMessageDialog(this, "Tie!");
                        playerOutput.setText("     Tie");
                        ties++;

                        //ends game so you can't click tiles
                        gameStarted = false;
                    }

                }
            }
    private void restartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restartButtonActionPerformed
        //set output to nothing
        playerOutput.setText("");
        
        //output the number of wins o, x has and the number of ties
        oWinOutput.setText("O wins = " + oWins); 
        xWinOutput1.setText("X wins = " + xWins); 
        tieOutput.setText("Ties = " + ties); 

        //sets button colour back to green
        startButton.setBackground(Color.GREEN);
        
        //sets all background back to white
        tile1.setBackground(Color.WHITE);
        tile2.setBackground(Color.WHITE);
        tile3.setBackground(Color.WHITE);
        tile4.setBackground(Color.WHITE);
        tile5.setBackground(Color.WHITE);
        tile6.setBackground(Color.WHITE);
        tile7.setBackground(Color.WHITE);
        tile8.setBackground(Color.WHITE);
        tile9.setBackground(Color.WHITE);
        tile10.setBackground(Color.WHITE);
        tile11.setBackground(Color.WHITE);
        tile12.setBackground(Color.WHITE);
        tile13.setBackground(Color.WHITE);
        tile14.setBackground(Color.WHITE);
        tile15.setBackground(Color.WHITE);
        tile16.setBackground(Color.WHITE);
        
        //does not start game
        gameStarted = false;
        
        //each button sets icon to white
        tile1.setIcon(cardBack);
        tile2.setIcon(cardBack);
        tile3.setIcon(cardBack);
        tile4.setIcon(cardBack);
        tile5.setIcon(cardBack);
        tile6.setIcon(cardBack);
        tile7.setIcon(cardBack);
        tile8.setIcon(cardBack);
        tile9.setIcon(cardBack);
        tile10.setIcon(cardBack);
        tile11.setIcon(cardBack);
        tile12.setIcon(cardBack);
        tile13.setIcon(cardBack);
        tile14.setIcon(cardBack);
        tile15.setIcon(cardBack);
        tile16.setIcon(cardBack);
        
        //loops through each element in the array
        //resets the array with different negative -999 numbers
        for (int i = 0; i < check[0].length; i++) {
            for (int j = 0; j < check.length; j++) {
                //sets each element to a different number
                check[i][j] = 999 + i + 12;

            }
        }
        
        //resets all buttons presses to false
        alreadyPressed = false;
        alreadyPressed2 = false;
        alreadyPressed3 = false;
        alreadyPressed4 = false;
        alreadyPressed5 = false;
        alreadyPressed6 = false;
        alreadyPressed7 = false;
        alreadyPressed8 = false;
        alreadyPressed9 = false;
        alreadyPressed10 = false;
        alreadyPressed11 = false;
        alreadyPressed12 = false;
        alreadyPressed13 = false;
        alreadyPressed14 = false;
        alreadyPressed15 = false;
        alreadyPressed16 = false;
           
        //resets gameDone variable 
        gameDone = 0;
        //resets button pressed to false
        startButtonPressed = false;
        //resets number variable
        number = 0;
        //reset status back to 0
        statusNum = 0;
    }//GEN-LAST:event_restartButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        
        //makes new window object
        StartingScreen window1 = new StartingScreen();
        
        //sets the starting window to visible
        window1.setVisible(true);
        
        //sets this window to be invisible
        this.setVisible(false);
        
    }//GEN-LAST:event_backButtonActionPerformed

    
        
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("FlatLafLight".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TicTacToeMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TicTacToeMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TicTacToeMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TicTacToeMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TicTacToeMain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel oWinOutput;
    private javax.swing.JLabel playerOutput;
    private javax.swing.JToggleButton restartButton;
    private javax.swing.JToggleButton startButton;
    private javax.swing.JLabel tieOutput;
    private javax.swing.JButton tile1;
    private javax.swing.JButton tile10;
    private javax.swing.JButton tile11;
    private javax.swing.JButton tile12;
    private javax.swing.JButton tile13;
    private javax.swing.JButton tile14;
    private javax.swing.JButton tile15;
    private javax.swing.JButton tile16;
    private javax.swing.JButton tile2;
    private javax.swing.JButton tile3;
    private javax.swing.JButton tile4;
    private javax.swing.JButton tile5;
    private javax.swing.JButton tile6;
    private javax.swing.JButton tile7;
    private javax.swing.JButton tile8;
    private javax.swing.JButton tile9;
    private javax.swing.JLabel xWinOutput1;
    // End of variables declaration//GEN-END:variables
}
